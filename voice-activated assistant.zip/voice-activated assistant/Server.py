from flask import Flask, request, jsonify, render_template
from assistant_logic import process_command


app = Flask(__name__)

@app.route('/')
def home():
    return render_template("assistant.html")

@app.route('/process', methods=['POST'])
def process():
    try:
        data = request.get_json()
        query = data.get("command", "")
        print("Received query:", query)
        response = process_command(query)
        return jsonify({"response": response})
    except Exception as e:
        print("Error:", e)
        return jsonify({"response": "Sorry, an error occurred."})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

